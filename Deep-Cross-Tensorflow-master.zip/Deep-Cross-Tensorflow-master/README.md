# Deep-Cross-Tensorflow
Ref: https://github.com/Nirvanada/Deep-and-Cross-Keras  
Simple tensorflow implementation for [Deep and Cross Network](https://arxiv.org/pdf/1708.05123.pdf), But the model need to be tuned by yourself and the model create by this project only achieves 76.66%.  
Data:download from https://www.kaggle.com/uciml/forest-cover-type-dataset/data 
