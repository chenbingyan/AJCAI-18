### Deep and Cross Network for Keras
Simple Keras implementation for [Deep and Cross Network](https://arxiv.org/pdf/1708.05123.pdf)
